from flask import Flask,render_template,request
app =Flask(__name__) 

@app.route('/')

def index():
	return render_template('index.html')

@app.route('/ques', methods=['GET', 'POST'])

def ques():
	if request.method =='POST':
		#print(requests.get['question_no.'])
		result=graph.run('''MATCH (h1:Hashtag)-[:Hashtags]->(k:Tweet)<-[:mentions]-(h:User)
	where h1.hashtag="HappyBirthdayJustinBieber"
       RETURN h1.hashtag As q1,COLLECT(k.tweetid) As q2,h.auth_screen_name As q3,Count(*) AS COUNT
       ORDER BY COUNT DESC
       ;
       
			''')      
		result1=result[result:result] 
		return render_template('index.html', **result1)
	else :
		return "this is GET"	

if __name__ == "__main__":
	app.run(debug=True)
